import { useEffect, useState } from "react";
import "./App.css";

const API_URL = "http://localhost:3000";

function descricaoClima(codigo) {
  if (codigo === 0) return { clima: "Céu limpo", icone: "☀️" };
  if ([1, 2].includes(codigo)) return { clima: "Parcialmente nublado", icone: "🌤️" };
  if (codigo === 3) return { clima: "Nublado", icone: "☁️" };
  if ([45, 48].includes(codigo)) return { clima: "Neblina", icone: "🌫️" };
  if ([51, 53, 55, 56, 57].includes(codigo)) return { clima: "Garoa", icone: "🌦️" };
  if ([61, 63, 65, 66, 67, 80, 81, 82].includes(codigo)) return { clima: "Chuva", icone: "🌧️" };
  if ([71, 73, 75, 77, 85, 86].includes(codigo)) return { clima: "Neve", icone: "❄️" };
  if ([95, 96, 99].includes(codigo)) return { clima: "Tempestade", icone: "⛈️" };
  return { clima: "Condição desconhecida", icone: "🌡️" };
}

function App() {
  const [cidade, setCidade] = useState("");
  const [resultado, setResultado] = useState(null);
  const [mensagem, setMensagem] = useState("");
  const [historico, setHistorico] = useState([]);
  const [carregando, setCarregando] = useState(false);

  async function carregarHistorico() {
    try {
      const resposta = await fetch(`${API_URL}/historico`);
      if (!resposta.ok) throw new Error("Não foi possível carregar o histórico.");
      setHistorico(await resposta.json());
    } catch {
      setMensagem("Não foi possível acessar o histórico. Inicie a API com npm run dev:all.");
    }
  }

  useEffect(() => {
    carregarHistorico();
  }, []);

  async function consultarClima(event) {
    event.preventDefault();
    const nomeCidade = cidade.trim();
    if (!nomeCidade) {
      setMensagem("Digite o nome de uma cidade para consultar.");
      setResultado(null);
      return;
    }

    setCarregando(true);
    setMensagem("Buscando o clima atual...");
    setResultado(null);

    try {
      // Primeiro encontra a cidade e suas coordenadas pelo serviço de geocodificação.
      const urlBusca = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(nomeCidade)}&count=1&language=pt&format=json`;
      const respostaBusca = await fetch(urlBusca);
      if (!respostaBusca.ok) throw new Error("Não foi possível pesquisar a cidade. Verifique sua conexão.");
      const dadosBusca = await respostaBusca.json();
      const local = dadosBusca.results?.[0];
      if (!local) throw new Error("Cidade não encontrada. Confira o nome e tente novamente.");

      // Usa as coordenadas encontradas para consultar o clima atual.
      const urlClima = `https://api.open-meteo.com/v1/forecast?latitude=${local.latitude}&longitude=${local.longitude}&current=temperature_2m,relative_humidity_2m,weather_code&timezone=auto`;
      const respostaClima = await fetch(urlClima);
      if (!respostaClima.ok) throw new Error("Não foi possível obter o clima desta cidade agora.");
      const dadosClima = await respostaClima.json();
      const atual = dadosClima.current;
      if (!atual) throw new Error("A API não retornou dados meteorológicos para esta cidade.");

      const condicao = descricaoClima(atual.weather_code);
      const nomeCompleto = [local.name, local.admin1, local.country].filter(Boolean).join(", ");
      const consulta = {
        cidade: nomeCompleto,
        temperatura: `${Math.round(atual.temperature_2m)}°C`,
        clima: condicao.clima,
        icone: condicao.icone,
        umidade: `${atual.relative_humidity_2m}%`,
        data: new Date().toLocaleString("pt-BR"),
      };

      setResultado(consulta);
      setMensagem("Clima atual consultado com sucesso.");
      try {
        const respostaHistorico = await fetch(`${API_URL}/historico`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(consulta),
        });
        if (!respostaHistorico.ok) throw new Error("Falha ao salvar histórico");
        await carregarHistorico();
      } catch {
        setMensagem("Clima consultado, mas não foi possível salvar no histórico. Verifique se a API está ligada.");
      }
    } catch (error) {
      setMensagem(error.message || "Ocorreu um erro ao consultar o clima.");
    } finally {
      setCarregando(false);
    }
  }

  return (
    <main className="app-shell">
      <section className="weather-card">
        <div className="eyebrow">CLIMA • CONSULTA</div>
        <h1>Previsão do tempo</h1>
        <p className="subtitle">Consulte o clima atual de cidades do Brasil e do mundo.</p>
        <form className="search-form" onSubmit={consultarClima}>
          <label className="sr-only" htmlFor="cidade">Nome da cidade</label>
          <input id="cidade" type="text" placeholder="Ex.: São Paulo, Lisboa, Tóquio..." value={cidade} onChange={(e) => setCidade(e.target.value)} />
          <button type="submit" disabled={carregando}>{carregando ? "Consultando…" : "Consultar"}</button>
        </form>
        {mensagem && <p className="message" role="status">{mensagem}</p>}
        {resultado && (
          <section className="result" aria-live="polite">
            <div className="result-heading">
              <span className="weather-icon" aria-hidden="true">{resultado.icone || "🌡️"}</span>
              <div><p className="result-label">Clima atual em</p><h2>{resultado.cidade}</h2></div>
            </div>
            <div className="metrics">
              <div className="metric"><span>Temperatura</span><strong>{resultado.temperatura}</strong></div>
              <div className="metric"><span>Condição</span><strong>{resultado.clima}</strong></div>
              <div className="metric"><span>Umidade</span><strong>{resultado.umidade}</strong></div>
            </div>
          </section>
        )}
      </section>

      <section className="history-card">
        <div className="history-heading"><div><div className="eyebrow">SUAS CONSULTAS</div><h2>Histórico recente</h2></div><button className="secondary-button" type="button" onClick={carregarHistorico}>Atualizar</button></div>
        {historico.length === 0 ? <p className="empty-state">As consultas salvas aparecerão aqui.</p> : (
          <ul className="history-list">{[...historico].reverse().slice(0, 8).map((item, index) => <li key={`${item.data || item.cidade}-${index}`}><div><strong>{item.cidade}</strong><span>{item.data || "Data não informada"}</span></div><div className="history-value"><strong>{item.temperatura}</strong><span>{item.clima}</span></div></li>)}</ul>
        )}
      </section>
      <footer>Os dados meteorológicos são consultados online pelo Open-Meteo. É necessária conexão com a internet.</footer>
    </main>
  );
}

export default App;
