# AulaReact — Previsão do tempo

Projeto didático em React + Vite com consulta de cidades de exemplo e histórico local via API Express.

## Requisitos
- Node.js LTS instalado
- npm

## Instalação
No terminal do VS Code, dentro da pasta `AulaReact`, execute:

```bash
npm install
```

## Executar
Abra dois terminais no VS Code.

Terminal 1 — API e histórico:
```bash
npm run server
```

Terminal 2 — aplicação React:
```bash
npm run dev
```

Abra o endereço local exibido pelo Vite no terminal.

## Cidades cadastradas
- São Paulo
- Curitiba
- Santa Catarina
- Rio de Janeiro

**Nota:** temperaturas, clima e umidade são valores fixos de demonstração, não previsões em tempo real. O histórico é salvo em `api/historico.json`. A integração com Firebase não está ativa neste projeto porque não havia configuração válida no arquivo `api/firebase.js`.
