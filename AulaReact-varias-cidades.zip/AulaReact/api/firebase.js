// A integração com Firebase está desativada neste projeto.
// O histórico é salvo localmente em api/historico.json.
export default null;
