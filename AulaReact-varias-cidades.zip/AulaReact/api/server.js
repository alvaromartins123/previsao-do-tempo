import express from "express";
import cors from "cors";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const PORT = process.env.PORT || 3000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const historyFile = path.join(__dirname, "historico.json");
app.use(cors());
app.use(express.json());

function readHistory() {
  try {
    if (!fs.existsSync(historyFile)) return [];
    const content = fs.readFileSync(historyFile, "utf8").trim();
    if (!content) return [];
    const data = JSON.parse(content);
    return Array.isArray(data) ? data : [];
  } catch (error) {
    console.error("Não foi possível ler o histórico:", error.message);
    return [];
  }
}

app.get("/historico", (_req, res) => res.json(readHistory()));
app.post("/historico", (req, res) => {
  const { cidade, temperatura, clima, umidade } = req.body ?? {};
  if (![cidade, temperatura, clima, umidade].every((value) => typeof value === "string")) {
    return res.status(400).json({ mensagem: "Dados da consulta inválidos." });
  }
  const historico = readHistory();
  historico.push({ cidade, temperatura, clima, umidade, data: req.body.data || new Date().toLocaleString("pt-BR") });
  try {
    fs.writeFileSync(historyFile, JSON.stringify(historico, null, 2), "utf8");
    return res.status(201).json({ mensagem: "Consulta salva", total: historico.length });
  } catch (error) {
    console.error("Não foi possível salvar o histórico:", error.message);
    return res.status(500).json({ mensagem: "Erro ao salvar o histórico." });
  }
});

app.listen(PORT, () => console.log(`Servidor rodando em http://localhost:${PORT}`));
